
#include "App.h"

Define_Module(App);

void App::initialize()
{
    // TODO - Generated method body
    cMessage *msg = new cMessage("Prova");
    /*Appena parte potrei fargli inviarea un messaggio
     * a un gate in uscita*/
    /*send si prende il puntatore al messaggio + nome gate*/
    send(msg, "gout");
    //in base con chi collego gout arriverà il messaggio
    //il messaggio viene inviato all'istante 0
    //sendDelayed invia il messaggio con un ritardo
    //conviene usarlo raramente
    //sendDelayed(msg,2.0, "gout");
    //il messaggio sarà schedulato al secondo 2, se non ci sono altri
    //messaggi schedulerà per primo


}

void App::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
    //la printf stampa nella console non nella interfaccia grafica di omnet
    EV <<"Ho ricevuto il messaggio:"<<msg-> getName() << endl;

}
